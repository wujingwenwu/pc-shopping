const recommend = [
    {
        "id": 6,
        "name": "为您推荐",
        "type": 2,
        "sortOrder": 6,
        "position": 1,
        "limitNum": 2,
        "status": 1,
        "remark": "",
        "created": 1509945461000,
        "updated": 1509945461000,
        "panelContents": [
            {
                "id": 66,
                "panelId": 6,
                "type": 0,
                "productId": 150635087972564,
                "sortOrder": 1,
                "fullUrl": "",
                "picUrl": "https://i.loli.net/2018/07/13/5b48a7f468bf2.png",
                "picUrl2": null,
                "picUrl3": null,
                "created": 1569839175000,
                "updated": 1569839175000,
                "salePrice": 1,
                "productName": "支付测试商品 IPhone X 全面屏 全面绽放",
                "subTitle": "此仅为支付测试商品 拍下不会发货",
                "productImageBig": "https://i.loli.net/2018/07/13/5b48a7f468bf2.png"
            },
            {
                "id": 48,
                "panelId": 6,
                "type": 0,
                "productId": 150642571432835,
                "sortOrder": 2,
                "fullUrl": null,
                "picUrl": "https://i.loli.net/2018/07/13/5b48a7f46be51.png",
                "picUrl2": null,
                "picUrl3": null,
                "created": 1524107896000,
                "updated": 1524107898000,
                "salePrice": 1,
                "productName": "捐赠商品",
                "subTitle": "您的捐赠将用于本站维护 给您带来更好的体验",
                "productImageBig": "https://i.loli.net/2018/07/13/5b48a7f46be51.png"
            }
        ]
    }
]

module.exports = recommend