module.exports = {
  secret: 'lpwq1225',
  whitePath: ['/', '/goods/home', '/goods/recommend', '/goods/allGoods', '/goods/detail', '/goods/search', '/users/login','/users/register']
}